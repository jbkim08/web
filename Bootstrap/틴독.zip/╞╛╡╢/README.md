TinDog 시작 파일들
